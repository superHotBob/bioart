export default function GenomeDataSintetic(){
    return (
        <div className="main">
            
        </div>
    )
}